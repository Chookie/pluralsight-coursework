## Responsive Typography Workshop Files

These are all the code files for my Responsive Typography workshops. It's set up as a self-contained site, and contains begin/end/working versions so you can work along with each section and know where you should end up.  


### Browser Compatibility

I firmly believe that the point is to be inclusive, so these files are meant to work on just about anything - even IE6. Or in Opera Mini. 

###Currently tested:

####Mac OS
> Safari  
> Chrome  
> Firefox  

####Windows
> Win7 / IE9  
> Win7 / IE10  
> XP / IE 6-8 (works but needs some love)  

####Mobile
> iOS  
> Android  
> Firefox OS


